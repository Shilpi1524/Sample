var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope) {
	 $scope.myObj = {
		"color" : "black",
		"padding" : "50px",
	  }
	  
     $scope.environment = 
	 {
		 
	"DEV": [{
		"location": "NDR",
		"name": "dpdev01.absa.co.za"

	}],
	"UAT": [{
			"location": "NDR",
			"name": "dpuat01.absa.co.za"

		},
		{
			"location": "DR",
			"name": "dpuat02.absa.co.za"

		}
	],
	"UATDMZ": [{
			"location": "NDR",
			"name": "dpdmzuat01.absa.co.za"

		},
		{
			"location": "DR",
			"name": "dpdmzuat02.absa.co.za"

		}
	],
	"PROD": [{
		"location": "NDR",
		"name": "tbd.absa.co.za"

	}],
	"PRODDMZ": [{
		"location": "NDR",
		"name": "tbd.absa.co.za"

	}]

	 }
	 
  
   $scope.action = ["DR to DC1", "DR to DC2"];
   
    var string;
   string1='';
   string2 ='';
   
   $scope.myFunc = function() {
   $scope.NDR='';
   $scope.DR='';
   angular.forEach($scope.selectedEnvironment,function(value,key){
	   if(value.location == "NDR")
     string1+=value.name+" ";
		else if(value.location == "DR")
     string2+=value.name+" ";

     }); 
   $scope.NDR=string1;
   $scope.DR=string2;
   string1='';
   string2='';
   };
		
	 });